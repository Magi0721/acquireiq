"""
AcquireIQ — RBI Compliance Guardrails
Checks every outreach message before sending.
Enforces TRAI DND rules, messaging windows, and consent requirements.
"""
from models import OutreachMessage, Channel
from datetime import datetime


# Keywords that violate RBI/TRAI outreach guidelines
_BANNED_PHRASES = [
    "guaranteed approval",
    "100% approved",
    "no documents needed",
    "instant loan",
    "free money",
    "earn lakhs",
    "click here now",
    "limited time only",
    "act now or lose",
]

# Allowed SMS/WhatsApp sending window (TRAI: 9 AM to 9 PM)
_ALLOWED_START = 9    # 9:00 AM
_ALLOWED_END   = 21   # 9:00 PM


class ComplianceResult:
    def __init__(self, passed: bool, violations: list[str]):
        self.passed     = passed
        self.violations = violations

    def __str__(self):
        if self.passed:
            return "✅ COMPLIANCE PASSED — Message cleared for sending."
        return "❌ COMPLIANCE FAILED:\n" + "\n".join(f"  - {v}" for v in self.violations)


class RBIComplianceGuard:
    """
    Checks outreach messages for:
    1. Banned phrases (misleading claims)
    2. Send time compliance (TRAI: 9AM–9PM only)
    3. Opt-out instruction presence (SMS/WhatsApp)
    4. Message length limits
    """

    def check(self, message: OutreachMessage) -> ComplianceResult:
        violations = []
        body_lower = message.body.lower()

        # Check 1: Banned phrases
        for phrase in _BANNED_PHRASES:
            if phrase in body_lower:
                violations.append(f"Banned phrase detected: '{phrase}'")

        # Check 2: Send time window
        try:
            hour = int(message.send_time.split(":")[0])
            meridiem = message.send_time.split(" ")[-1].upper()
            if meridiem == "PM" and hour != 12:
                hour += 12
            elif meridiem == "AM" and hour == 12:
                hour = 0
            if not (_ALLOWED_START <= hour < _ALLOWED_END):
                violations.append(
                    f"Send time {message.send_time} outside TRAI allowed window (9 AM – 9 PM)"
                )
        except Exception:
            pass  # If parsing fails, don't block

        # Check 3: Opt-out clause for SMS/WhatsApp
        if message.channel in (Channel.SMS, Channel.WHATSAPP):
            if "stop" not in body_lower and "opt out" not in body_lower:
                violations.append(
                    "Missing opt-out instruction (TRAI mandate: 'Reply STOP to opt out')"
                )

        # Check 4: Length
        if len(message.body) > 1000:
            violations.append(f"Message too long ({len(message.body)} chars). Max 1000.")

        return ComplianceResult(passed=len(violations) == 0, violations=violations)
