"""
AcquireIQ — FastAPI Backend
Serves the acquisition funnel data for the branch manager dashboard.
Run with: uvicorn dashboard.api:app --reload
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from models import LeadStatus

app = FastAPI(
    title="AcquireIQ API",
    description="Agentic AI Customer Acquisition — SBI Branch Manager Dashboard",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── In-memory store (replace with PostgreSQL in production) ──────────────────
_pipeline: list[dict] = []


class RunRequest(BaseModel):
    max_prospects: int = 3
    tier_filter: Optional[int] = None
    prospect_response: str = ""


@app.get("/")
def root():
    return {"message": "AcquireIQ API running", "version": "1.0.0"}


@app.get("/funnel")
def get_funnel():
    """Return funnel counts for dashboard."""
    stages = {s.value: 0 for s in LeadStatus}
    for lead in _pipeline:
        status = lead.get("status", "discovered")
        stages[status] = stages.get(status, 0) + 1
    return {
        "total":  len(_pipeline),
        "stages": stages,
        "leads":  _pipeline,
    }


@app.post("/run")
def run_pipeline(req: RunRequest):
    """
    Trigger the full AcquireIQ agent pipeline.
    Discovers prospects, profiles them, generates outreach, nurtures.
    """
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

    from agents import DiscoveryAgent, ProfilingAgent, OutreachAgent, NurtureAgent
    from data.compliance import RBIComplianceGuard

    discovery  = DiscoveryAgent(max_prospects=req.max_prospects)
    profiler   = ProfilingAgent()
    outreach   = OutreachAgent()
    nurture    = NurtureAgent()
    compliance = RBIComplianceGuard()

    results = []

    prospects = discovery.discover(tier_filter=req.tier_filter)
    for prospect in prospects:
        try:
            # Stage 1: Profile
            lead = profiler.profile(prospect)

            # Stage 2: Generate outreach
            message = outreach.generate(lead)

            # Stage 3: Compliance check
            comp_result = compliance.check(message)

            # Stage 4: Nurture decision
            nurture_result = nurture.decide(lead, req.prospect_response)

            entry = {
                "id":       prospect.id,
                "name":     prospect.name,
                "location": f"{prospect.location}, {prospect.state}",
                "segment":  prospect.segment,
                "score":    lead.score,
                "product":  lead.recommended_product.value,
                "financial_health": lead.financial_health,
                "reasoning": lead.reasoning,
                "channel":  message.channel.value,
                "language": message.language.value,
                "send_time": message.send_time,
                "message":  message.body,
                "subject":  message.subject,
                "compliance_passed": comp_result.passed,
                "compliance_notes":  comp_result.violations,
                "nurture_action":    nurture_result.action,
                "nurture_message":   nurture_result.message,
                "escalate_to_rm":    nurture_result.escalate,
                "status":   "contacted" if comp_result.passed else "dropped",
                "intent_signal": prospect.intent_signal,
            }

            _pipeline.append(entry)
            results.append(entry)

        except Exception as e:
            results.append({"id": prospect.id, "error": str(e), "status": "dropped"})

    return {"processed": len(results), "results": results}


@app.delete("/funnel/reset")
def reset_pipeline():
    """Clear the pipeline (for demo resets)."""
    _pipeline.clear()
    return {"message": "Pipeline cleared."}
