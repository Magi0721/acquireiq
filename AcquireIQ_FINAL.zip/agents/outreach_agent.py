"""
AcquireIQ — Agent 3: Outreach Agent
Generates hyper-personalized, multilingual outreach messages.
Selects optimal channel and send time per prospect.
"""
import openai
from models import LeadProfile, OutreachMessage, Channel, Language, OPENAI_API_KEY, OPENAI_MODEL


# Best send times per segment (based on behavioral patterns)
_SEND_TIME_MAP = {
    "msme_owner":        "10:30 AM",
    "home_seeker":       "07:30 PM",
    "first_time_earner": "08:00 PM",
    "rural_farmer":      "06:30 AM",
    "default":           "11:00 AM",
}

# Best channel per tier
_CHANNEL_MAP = {
    1: Channel.EMAIL,
    2: Channel.WHATSAPP,
    3: Channel.SMS,
}

# Language instruction for LLM
_LANG_INSTRUCTION = {
    Language.ENGLISH: "Write in clear, friendly English.",
    Language.HINDI:   "Write in simple, conversational Hindi (Devanagari script).",
    Language.TAMIL:   "Write in simple Tamil (Tamil script).",
    Language.TELUGU:  "Write in simple Telugu (Telugu script).",
    Language.KANNADA: "Write in simple Kannada (Kannada script).",
}


class OutreachAgent:
    """
    Generates personalized outreach messages in the prospect's language.
    Selects optimal channel (SMS/WhatsApp/Email) and send time.
    All messages are under 160 words and RBI-compliant in tone.
    """

    def __init__(self):
        self.client = openai.OpenAI(api_key=OPENAI_API_KEY)

    def generate(self, lead: LeadProfile) -> OutreachMessage:
        """Generate a personalized outreach message for a profiled lead."""

        p = lead.prospect
        channel  = _CHANNEL_MAP.get(p.tier, Channel.WHATSAPP)
        lang     = p.language
        send_time = _SEND_TIME_MAP.get(p.segment, _SEND_TIME_MAP["default"])
        lang_instr = _LANG_INSTRUCTION.get(lang, _LANG_INSTRUCTION[Language.ENGLISH])

        is_email   = channel == Channel.EMAIL
        format_instr = (
            "Write a short professional email with a subject line (prefix with 'SUBJECT: ') "
            "and body (prefix with 'BODY: '). Keep under 120 words."
            if is_email else
            "Write a short WhatsApp/SMS message. No subject needed. Keep under 80 words. "
            "Start with 'Namaste' or appropriate greeting for the language."
        )

        prompt = f"""
You are an SBI (State Bank of India) outreach specialist.
Write a highly personalized, warm message to this prospect.

PROSPECT:
- Name: {p.name}
- Location: {p.location}, {p.state}
- Life Situation: {p.intent_signal}
- Recommended Product: {lead.recommended_product.value}
- Score: {lead.score}/100
- Financial Health: {lead.financial_health}

RULES:
1. {lang_instr}
2. {format_instr}
3. Reference their SPECIFIC situation naturally (e.g., mention their new business, new job, or property search).
4. Mention the SBI product benefit in ONE sentence — do not oversell.
5. End with a clear, low-pressure call to action (visit nearest SBI branch or call 1800 1234).
6. Never promise guaranteed approval or specific interest rates.
7. TRAI compliant: include "Reply STOP to opt out" at the end for SMS/WhatsApp.
"""

        response = self.client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=400,
        )

        raw = response.choices[0].message.content.strip()

        subject = None
        body    = raw

        if is_email and "SUBJECT:" in raw and "BODY:" in raw:
            parts   = raw.split("BODY:", 1)
            subject = parts[0].replace("SUBJECT:", "").strip()
            body    = parts[1].strip()

        return OutreachMessage(
            lead_id=p.id,
            channel=channel,
            language=lang,
            subject=subject,
            body=body,
            send_time=send_time,
        )

    def describe(self) -> str:
        return (
            "Outreach Agent: Generates multilingual, context-aware messages "
            "via the optimal channel at the best time for each prospect."
        )
