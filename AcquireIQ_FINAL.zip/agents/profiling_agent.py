"""
AcquireIQ — Agent 2: Profiling Agent
Uses LLM to score each prospect (0-100) and match the right SBI product.
"""
import json
import openai
from models import Prospect, LeadProfile, SBIProduct, LeadStatus, OPENAI_API_KEY, OPENAI_MODEL


class ProfilingAgent:
    """
    Scores leads 0-100 on conversion probability.
    Estimates financial health from proxy signals.
    Auto-matches the best SBI product to each prospect.
    """

    def __init__(self):
        self.client = openai.OpenAI(api_key=OPENAI_API_KEY)

    def profile(self, prospect: Prospect) -> LeadProfile:
        """Score and profile a single prospect using LLM reasoning."""

        prompt = f"""
You are a senior SBI (State Bank of India) relationship manager and credit analyst.

Analyze this prospect and return a JSON object with your assessment.

PROSPECT DETAILS:
- Name: {prospect.name}
- Location: {prospect.location}, {prospect.state} (Tier-{prospect.tier} city)
- Segment: {prospect.segment}
- Intent Signal: {prospect.intent_signal}
- Preferred Language: {prospect.language}

SBI PRODUCTS AVAILABLE:
- Home Loan
- MSME Loan
- Personal Loan
- Savings Account
- Credit Card
- Fixed Deposit
- Jan Dhan Account
- Kisan Credit Card

TASK:
1. Score this prospect from 0-100 on likelihood to convert to an SBI customer.
   (100 = very likely, 0 = very unlikely)
2. Estimate financial health: "low", "medium", or "high"
3. Pick the single BEST SBI product for this prospect.
4. Give a 1-sentence reasoning for your recommendation.

SCORING GUIDE:
- Tier-3 / rural + no banking = 70+ (high need, SBI financial inclusion mandate)
- New business registration = 80+ (urgent need for current account + MSME loan)
- Property search active = 75+ (home loan intent is explicit)
- New employment = 65+ (savings account + credit card need)
- Adjust down slightly if signal is weak or indirect.

Return ONLY valid JSON, no markdown, no explanation:
{{
  "score": <integer 0-100>,
  "financial_health": "<low|medium|high>",
  "recommended_product": "<exact product name from list above>",
  "reasoning": "<one sentence>"
}}
"""

        response = self.client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=300,
        )

        raw = response.choices[0].message.content.strip()

        # Parse JSON safely
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            # Fallback defaults if LLM returns unexpected format
            data = {
                "score": 60,
                "financial_health": "medium",
                "recommended_product": "Savings Account",
                "reasoning": "Default profile — manual review recommended.",
            }

        # Map product string to enum
        product_map = {p.value: p for p in SBIProduct}
        product = product_map.get(data["recommended_product"], SBIProduct.SAVINGS_ACCOUNT)

        return LeadProfile(
            prospect=prospect,
            score=int(data["score"]),
            financial_health=data["financial_health"],
            recommended_product=product,
            reasoning=data["reasoning"],
            status=LeadStatus.PROFILED,
        )

    def describe(self) -> str:
        return (
            "Profiling Agent: Uses GPT-4o-mini to score each lead 0-100, "
            "estimate financial health, and match the best SBI product."
        )
