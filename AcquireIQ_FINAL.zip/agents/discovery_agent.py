"""
AcquireIQ — Agent 1: Discovery Agent
Simulates scraping public data sources for high-intent prospects.
In production: connects to MCA21, RERA, job portals, LinkedIn public data.
"""
import uuid
import random
from models import Prospect, Language


# ── Simulated public data pool ─────────────────────────────────────────────
# In production these come from actual web scraping / API calls to:
# MCA21 (new business registrations), RERA (property), job portals, etc.

_SAMPLE_SIGNALS = [
    {
        "name": "Arjun Sharma",
        "location": "Lucknow",
        "state": "Uttar Pradesh",
        "tier": 2,
        "segment": "msme_owner",
        "intent_signal": "New business registered on MCA21 portal (Private Ltd, ₹5L capital)",
        "language": Language.HINDI,
    },
    {
        "name": "Priya Nair",
        "location": "Coimbatore",
        "state": "Tamil Nadu",
        "tier": 2,
        "segment": "home_seeker",
        "intent_signal": "Active property search on MagicBricks — 3BHK listings viewed 12 times",
        "language": Language.TAMIL,
    },
    {
        "name": "Ravi Kumar",
        "location": "Patna",
        "state": "Bihar",
        "tier": 2,
        "segment": "first_time_earner",
        "intent_signal": "New job posted on LinkedIn — Software Engineer, joined TCS Patna",
        "language": Language.HINDI,
    },
    {
        "name": "Sunita Devi",
        "location": "Varanasi",
        "state": "Uttar Pradesh",
        "tier": 3,
        "segment": "rural_farmer",
        "intent_signal": "Located in agriculture district; no formal banking footprint detected",
        "language": Language.HINDI,
    },
    {
        "name": "Mohammed Rafiq",
        "location": "Hubli",
        "state": "Karnataka",
        "tier": 2,
        "segment": "msme_owner",
        "intent_signal": "GST registration filed — textile trading business, annual turnover ₹18L",
        "language": Language.KANNADA,
    },
    {
        "name": "Deepa Krishnan",
        "location": "Madurai",
        "state": "Tamil Nadu",
        "tier": 2,
        "segment": "home_seeker",
        "intent_signal": "RERA listing search — affordable housing scheme, budget ₹25–35L",
        "language": Language.TAMIL,
    },
    {
        "name": "Amit Patel",
        "location": "Surat",
        "state": "Gujarat",
        "tier": 2,
        "segment": "msme_owner",
        "intent_signal": "MCA21: New Pvt Ltd registered — diamond trading, 3 partners",
        "language": Language.ENGLISH,
    },
    {
        "name": "Kavitha Reddy",
        "location": "Vijayawada",
        "state": "Andhra Pradesh",
        "tier": 2,
        "segment": "first_time_earner",
        "intent_signal": "College graduation + job placement at Infosys — campus hire signal",
        "language": Language.TELUGU,
    },
    {
        "name": "Suresh Babu",
        "location": "Tirunelveli",
        "state": "Tamil Nadu",
        "tier": 3,
        "segment": "rural_farmer",
        "intent_signal": "Agricultural land owner — eligible for Kisan Credit Card scheme",
        "language": Language.TAMIL,
    },
    {
        "name": "Nisha Gupta",
        "location": "Jaipur",
        "state": "Rajasthan",
        "tier": 2,
        "segment": "first_time_earner",
        "intent_signal": "LinkedIn: New role at Wipro BPO, Jaipur — first employment post MBA",
        "language": Language.HINDI,
    },
]


class DiscoveryAgent:
    """
    Discovers high-intent prospects from public data signals.

    Production implementation would:
    - Scrape MCA21 for new business registrations
    - Monitor RERA portals for property searches
    - Parse job portals for new employment signals
    - Use geographic filters to prioritize tier-2/3 cities
    - Apply RBI TRAI DND pre-check before adding to pipeline
    """

    def __init__(self, max_prospects: int = 5):
        self.max_prospects = max_prospects

    def discover(self, tier_filter: int = None) -> list[Prospect]:
        """
        Main discovery method. Returns a list of Prospect objects.
        tier_filter: 1=metro, 2=city, 3=rural — None means all
        """
        pool = _SAMPLE_SIGNALS
        if tier_filter:
            pool = [p for p in pool if p["tier"] == tier_filter]

        # Simulate random discovery from the pool
        selected = random.sample(pool, min(self.max_prospects, len(pool)))

        prospects = []
        for raw in selected:
            prospect = Prospect(
                id=str(uuid.uuid4())[:8],
                **raw,
            )
            prospects.append(prospect)

        return prospects

    def describe(self) -> str:
        return (
            "Discovery Agent: Scans MCA21, RERA, job portals, and geographic "
            "signals to find high-intent prospects in tier-2/3 cities and rural India."
        )
