"""
AcquireIQ — Agent 4: Nurture Agent
Handles follow-up sequencing, objection responses, and hot lead escalation.
"""
import openai
from models import LeadProfile, FollowUpResult, OPENAI_API_KEY, OPENAI_MODEL

# Responses that indicate interest
_POSITIVE_SIGNALS = ["interested", "tell me more", "how", "yes", "ok", "sure", "call me", "visit"]
# Responses that indicate objection
_OBJECTION_SIGNALS = ["not interested", "no", "stop", "expensive", "busy", "later", "don't need"]


class NurtureAgent:
    """
    Decides what to do next based on prospect's response:
    - No response → adaptive follow-up with different angle
    - Objection → AI-generated counter-message
    - Interest → escalate to human RM immediately
    - Score 85+ → always escalate regardless of response
    """

    def __init__(self):
        self.client = openai.OpenAI(api_key=OPENAI_API_KEY)

    def decide(self, lead: LeadProfile, prospect_response: str = "") -> FollowUpResult:
        """
        Decide next action based on lead score and prospect response.

        prospect_response: what the prospect replied (empty = no response yet)
        """
        p = lead.prospect
        response_lower = prospect_response.lower().strip()

        # Rule 1: High-score leads always escalate to RM
        if lead.score >= 85:
            return FollowUpResult(
                lead_id=p.id,
                action="escalate_to_rm",
                message=(
                    f"🔴 HOT LEAD — Escalate immediately to RM.\n"
                    f"Prospect: {p.name}, {p.location}\n"
                    f"Score: {lead.score}/100\n"
                    f"Product: {lead.recommended_product.value}\n"
                    f"Signal: {p.intent_signal}\n"
                    f"Recommended action: Personal call within 2 hours."
                ),
                escalate=True,
                reason=f"Score {lead.score} ≥ 85 threshold — automatic RM escalation.",
            )

        # Rule 2: Positive response → escalate
        if any(sig in response_lower for sig in _POSITIVE_SIGNALS):
            return FollowUpResult(
                lead_id=p.id,
                action="escalate_to_rm",
                message=(
                    f"✅ Prospect {p.name} expressed interest.\n"
                    f"Response: '{prospect_response}'\n"
                    f"Product interest: {lead.recommended_product.value}\n"
                    f"Escalate to RM for immediate follow-up."
                ),
                escalate=True,
                reason="Prospect responded positively — RM handoff triggered.",
            )

        # Rule 3: Objection → LLM generates counter-message
        if any(sig in response_lower for sig in _OBJECTION_SIGNALS):
            return self._handle_objection(lead, prospect_response)

        # Rule 4: No response → adaptive follow-up
        return self._adaptive_followup(lead)

    def _handle_objection(self, lead: LeadProfile, objection: str) -> FollowUpResult:
        """Use LLM to craft a soft, helpful objection response."""
        p = lead.prospect
        prompt = f"""
You are a polite, helpful SBI customer service agent.
A prospect has raised an objection to your outreach.

PROSPECT: {p.name}, {p.location}
PRODUCT: {lead.recommended_product.value}
THEIR OBJECTION: "{objection}"

Write a SHORT, warm 2-3 sentence response that:
1. Acknowledges their concern genuinely
2. Offers one specific, relevant reason to reconsider
3. Gives them a low-pressure way out ("No obligation, just here to help")
4. Does NOT pressure or repeat the sales pitch aggressively

Write only the message, no labels.
"""
        response = self.client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.6,
            max_tokens=150,
        )
        message = response.choices[0].message.content.strip()

        return FollowUpResult(
            lead_id=p.id,
            action="objection_handled",
            message=message,
            escalate=False,
            reason=f"Objection detected: '{objection}' — LLM counter-message generated.",
        )

    def _adaptive_followup(self, lead: LeadProfile) -> FollowUpResult:
        """Generate a different-angle follow-up for non-responding prospects."""
        p = lead.prospect
        prompt = f"""
You are an SBI outreach specialist.
A prospect hasn't responded to your first message.

PROSPECT: {p.name}, {p.location}, {p.state}
SITUATION: {p.intent_signal}
PRODUCT: {lead.recommended_product.value}

Write a SHORT follow-up message (under 60 words) using a DIFFERENT angle than the first:
- First message was about the product benefit
- This follow-up should focus on a story, statistic, or specific advantage relevant to their situation
- End with one simple question to invite a response
- Friendly and brief — not pushy

Write only the message.
"""
        response = self.client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=150,
        )
        message = response.choices[0].message.content.strip()

        return FollowUpResult(
            lead_id=p.id,
            action="follow_up",
            message=message,
            escalate=False,
            reason="No response to initial outreach — adaptive follow-up with different angle.",
        )

    def describe(self) -> str:
        return (
            "Nurture Agent: Adapts follow-up based on prospect response. "
            "Handles objections with AI counter-messaging. "
            "Escalates hot leads (score ≥ 85) to human RM automatically."
        )
