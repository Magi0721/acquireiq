"""
AcquireIQ — CLI Pipeline Runner
Runs the full 4-agent pipeline and displays results in the terminal.
Perfect for demo purposes.

Usage:
    python main.py                    # Run with 3 prospects
    python main.py --count 5          # Run with 5 prospects
    python main.py --tier 2           # Only tier-2 city prospects
    python main.py --response "yes"   # Simulate a prospect reply
"""
import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box
from rich.text import Text
import time

# Local imports
from models import Language
from agents import DiscoveryAgent, ProfilingAgent, OutreachAgent, NurtureAgent
from data.compliance import RBIComplianceGuard

app_cli = typer.Typer()
console  = Console()


def print_banner():
    console.print(Panel.fit(
        "[bold cyan]AcquireIQ[/bold cyan] [white]— Agentic AI for Bank Customer Acquisition[/white]\n"
        "[dim]Built for SBI Hackathon 2025 · Theme: Agentic AI & Emerging Tech[/dim]",
        border_style="cyan",
    ))


def score_color(score: int) -> str:
    if score >= 80: return "green"
    if score >= 60: return "yellow"
    return "red"


@app_cli.command()
def run(
    count:    int           = typer.Option(3,    "--count",    "-n", help="Number of prospects to discover"),
    tier:     Optional[int] = typer.Option(None, "--tier",     "-t", help="Tier filter: 1=metro, 2=city, 3=rural"),
    response: str           = typer.Option("",   "--response", "-r", help="Simulate prospect response (e.g. 'not interested')"),
):
    """Run the full AcquireIQ agentic pipeline."""

    print_banner()
    console.print()

    # ── Initialise agents ────────────────────────────────────────────────────
    discovery  = DiscoveryAgent(max_prospects=count)
    profiler   = ProfilingAgent()
    outreach   = OutreachAgent()
    nurture    = NurtureAgent()
    compliance = RBIComplianceGuard()

    results = []

    # ── Stage 1: Discovery ───────────────────────────────────────────────────
    console.print("[bold blue]🔍 AGENT 1 — Discovery Agent[/bold blue]")
    console.print("[dim]Scanning MCA21, RERA, job portals for high-intent signals...[/dim]")

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
        task = progress.add_task("Discovering prospects...", total=None)
        time.sleep(0.8)
        prospects = discovery.discover(tier_filter=tier)
        progress.update(task, completed=True)

    console.print(f"[green]✓ Found {len(prospects)} prospects[/green]\n")

    for p in prospects:
        tier_label = {1: "Metro", 2: "City", 3: "Rural"}.get(p.tier, "Unknown")
        console.print(f"  [cyan]●[/cyan] [bold]{p.name}[/bold] · {p.location} [{tier_label}]")
        console.print(f"    [dim]{p.intent_signal}[/dim]")

    console.print()

    # ── Process each prospect ─────────────────────────────────────────────────
    for i, prospect in enumerate(prospects, 1):
        console.rule(f"[bold]Prospect {i}/{len(prospects)}: {prospect.name}[/bold]")

        # Stage 2: Profiling
        console.print("[bold yellow]📊 AGENT 2 — Profiling Agent[/bold yellow]")
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
            task = progress.add_task(f"Profiling {prospect.name}...", total=None)
            lead = profiler.profile(prospect)
            progress.update(task, completed=True)

        sc = lead.score
        color = score_color(sc)
        console.print(f"  Score:    [{color}]{sc}/100[/{color}]")
        console.print(f"  Product:  [bold]{lead.recommended_product.value}[/bold]")
        console.print(f"  Health:   {lead.financial_health.title()}")
        console.print(f"  Reason:   [dim]{lead.reasoning}[/dim]\n")

        # Stage 3: Outreach
        console.print("[bold magenta]💬 AGENT 3 — Outreach Agent[/bold magenta]")
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
            task = progress.add_task("Generating personalized message...", total=None)
            msg = outreach.generate(lead)
            progress.update(task, completed=True)

        console.print(f"  Channel:  {msg.channel.value.upper()} ({msg.language.value})")
        console.print(f"  Send at:  {msg.send_time}")
        if msg.subject:
            console.print(f"  Subject:  {msg.subject}")
        console.print(Panel(
            msg.body,
            title="[bold]Generated Message[/bold]",
            border_style="magenta",
            padding=(1, 2),
        ))

        # Compliance check
        comp = compliance.check(msg)
        if comp.passed:
            console.print(f"  [green]✅ RBI Compliance: PASSED[/green]\n")
        else:
            console.print(f"  [red]❌ RBI Compliance: FAILED[/red]")
            for v in comp.violations:
                console.print(f"    [red]· {v}[/red]")
            console.print()

        # Stage 4: Nurture
        console.print("[bold green]🔁 AGENT 4 — Nurture Agent[/bold green]")
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
            task = progress.add_task("Deciding next action...", total=None)
            nurture_result = nurture.decide(lead, response)
            progress.update(task, completed=True)

        action_colors = {
            "escalate_to_rm":    "red",
            "follow_up":         "yellow",
            "objection_handled": "blue",
        }
        action_color = action_colors.get(nurture_result.action, "white")
        console.print(f"  Action:   [{action_color}]{nurture_result.action.upper().replace('_', ' ')}[/{action_color}]")
        console.print(f"  Reason:   [dim]{nurture_result.reason}[/dim]")
        if nurture_result.escalate:
            console.print(Panel(
                nurture_result.message,
                title="[bold red]🔴 RM ESCALATION ALERT[/bold red]",
                border_style="red",
            ))
        console.print()

        results.append({
            "name":     prospect.name,
            "location": prospect.location,
            "score":    lead.score,
            "product":  lead.recommended_product.value,
            "channel":  msg.channel.value,
            "action":   nurture_result.action,
            "escalate": nurture_result.escalate,
            "compliant": comp.passed,
        })

    # ── Summary Table ─────────────────────────────────────────────────────────
    console.rule("[bold]ACQUISITION FUNNEL SUMMARY[/bold]")
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("Prospect",  style="bold")
    table.add_column("Location")
    table.add_column("Score",     justify="center")
    table.add_column("Product")
    table.add_column("Channel",   justify="center")
    table.add_column("Action",    justify="center")
    table.add_column("✅ Safe",    justify="center")

    for r in results:
        sc_text = Text(str(r["score"]), style=score_color(r["score"]))
        table.add_row(
            r["name"],
            r["location"],
            sc_text,
            r["product"],
            r["channel"].upper(),
            r["action"].replace("_", " ").title(),
            "✅" if r["compliant"] else "❌",
        )

    console.print(table)
    console.print()

    escalated = sum(1 for r in results if r["escalate"])
    compliant  = sum(1 for r in results if r["compliant"])

    console.print(Panel(
        f"[bold]Total Prospects:[/bold]  {len(results)}\n"
        f"[bold]Outreach Sent:[/bold]    {compliant} (RBI-compliant)\n"
        f"[bold]RM Escalations:[/bold]   [red]{escalated}[/red] hot leads\n"
        f"[bold]Blocked:[/bold]          {len(results) - compliant} (failed compliance)",
        title="[bold cyan]AcquireIQ Pipeline Complete[/bold cyan]",
        border_style="cyan",
    ))


if __name__ == "__main__":
    app_cli()
