# AcquireIQ 🏦🤖
### Agentic AI for Intelligent Bank Customer Acquisition

> **SBI Hackathon 2025** · Theme: Agentic AI & Emerging Tech · Problem Statement: Customer Acquisition

[![Python](https://img.shields.io/badge/Python-3.11+-blue?logo=python)](https://python.org)
[![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4o--mini-green?logo=openai)](https://openai.com)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-teal?logo=fastapi)](https://fastapi.tiangolo.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

---

## 🧠 What is AcquireIQ?

AcquireIQ is a **multi-agent AI system** that helps SBI autonomously find, profile, and convert potential customers — entirely on autopilot.

**The Problem:**
- 190M+ Indians remain unbanked — not because they don't need banking products, but because no one reached them at the right moment
- SBI's current outreach relies on generic SMS blasts with <5% conversion rates
- Zero personalization, no multilingual support, no intelligent follow-up

**The Solution:**
AcquireIQ deploys 4 specialized AI agents in a pipeline:

```
[Public Data] → Discovery Agent → Profiling Agent → Outreach Agent → Nurture Agent → [RM / Convert]
```

---

## 🤖 The 4 Agents

| Agent | What it does |
|-------|-------------|
| **Discovery Agent** | Scans MCA21, RERA, job portals for high-intent signals; prioritizes tier-2/3 cities |
| **Profiling Agent** | Scores each lead 0–100, estimates financial health, matches the right SBI product |
| **Outreach Agent** | Generates personalized messages in Hindi, Tamil, English, Telugu, Kannada via optimal channel |
| **Nurture Agent** | Adapts follow-up based on prospect response; handles objections; escalates hot leads to RM |

---

## ✨ Key Features

- 🔍 **Intent signal detection** — MCA21 business registrations, RERA property searches, job portal signals, life event detection
- 🎯 **AI lead scoring** — GPT-4o-mini scores each lead 0–100 on conversion probability
- 🏦 **Product matching** — Auto-selects best SBI product (Home Loan, MSME Loan, Jan Dhan, KCC, Credit Card, etc.)
- 🌐 **Multilingual outreach** — Hindi, Tamil, Telugu, Kannada, English
- 📱 **Multi-channel** — SMS, WhatsApp, Email with optimal send-time prediction
- 🔁 **Adaptive follow-up** — Different angle if no response; AI objection handling
- 🔴 **Hot lead escalation** — Score ≥85 or positive response → instant RM alert
- 🛡️ **RBI compliance** — Every message checked for banned phrases, TRAI send windows, opt-out clauses

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| AI / LLM | OpenAI GPT-4o-mini (via API) |
| Agent Orchestration | Python, custom pipeline |
| Backend API | FastAPI + Uvicorn |
| Data Discovery | BeautifulSoup4, Requests (simulated public data) |
| CLI Interface | Rich, Typer |
| Compliance | Rule-based RBI/TRAI guardrail layer |
| Models | Pydantic v2 |

---

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/acquireiq.git
cd acquireiq
```

### 2. Create a Virtual Environment (Windows)
```bash
python -m venv venv
venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Set Up Your API Key
```bash
# Copy the example env file
copy .env.example .env

# Open .env in Notepad and add your OpenAI API key:
# OPENAI_API_KEY=sk-your-key-here
```
> Get your free OpenAI API key at: https://platform.openai.com/api-keys

### 5. Run the Pipeline (CLI Demo)
```bash
python main.py
```

**Other options:**
```bash
python main.py --count 5              # Discover 5 prospects
python main.py --tier 2              # Only tier-2 city prospects
python main.py --tier 3              # Only rural prospects
python main.py --response "yes"      # Simulate prospect saying yes → triggers RM escalation
python main.py --response "not interested"  # Simulate objection → AI counter-message
```

### 6. Run the API Server (optional)
```bash
uvicorn dashboard.api:app --reload
```
Then open: http://localhost:8000/docs (interactive API docs)

---

## 📁 Project Structure

```
acquireiq/
├── main.py                    # CLI demo runner (start here)
├── models.py                  # Shared data models (Prospect, LeadProfile, etc.)
├── requirements.txt
├── .env.example               # Copy to .env and add your API key
│
├── agents/
│   ├── discovery_agent.py     # Agent 1: Finds high-intent prospects
│   ├── profiling_agent.py     # Agent 2: Scores & profiles with LLM
│   ├── outreach_agent.py      # Agent 3: Generates multilingual messages
│   └── nurture_agent.py       # Agent 4: Follow-up, objections, RM escalation
│
├── data/
│   └── compliance.py          # RBI/TRAI compliance guardrails
│
└── dashboard/
    └── api.py                 # FastAPI backend (branch manager dashboard)
```

---

## 🎯 Target Segments

| Segment | Signal Source | SBI Product |
|---------|--------------|-------------|
| First-time earners | Job portals, LinkedIn | Savings Account, Credit Card |
| Small business owners | MCA21, GST filings | MSME Loan, Current Account |
| Home seekers | RERA, property portals | Home Loan, Insurance |
| Rural & semi-urban | Geographic signals | Jan Dhan, PM Mudra, KCC |

---

## 💼 Business Model

- **B2B SaaS** — Monthly subscription per SBI branch
- **Performance-based** — Cost-per-acquired-customer pricing option
- **Scalable** — Same agent architecture works for PNB, BOB, Canara, NBFCs

**Market opportunity:** 22,542 SBI branches × ₹X/month = massive recurring revenue potential

---

## 🛡️ RBI Compliance

Every outreach message is automatically checked for:
- ❌ Banned phrases (e.g., "guaranteed approval", "instant loan")
- ⏰ TRAI send time window (9 AM – 9 PM only)
- 📵 Opt-out clause presence (TRAI mandate)
- 📏 Message length limits

Messages that fail compliance are **blocked** before sending.

---

## 👩‍💻 Author

**Magi Vaishnavi S**
AIML Engineering Student
SBI Hackathon 2025

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.
